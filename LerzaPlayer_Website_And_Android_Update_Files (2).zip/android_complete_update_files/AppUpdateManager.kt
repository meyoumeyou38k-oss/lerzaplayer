package com.lerzaplayer.update

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(
    val versionName: String,
    val versionCode: Int,
    val releaseTitle: String,
    val changelog: List<String>,
    val apkUrl: String,
    val apkSize: String,
    val isForceUpdate: Boolean,
    val minSdk: Int
)

sealed class UpdateDownloadState {
    object Idle : UpdateDownloadState()
    data class Downloading(val progressPercent: Int, val downloadedBytes: Long, val totalBytes: Long) : UpdateDownloadState()
    data class DownloadCompleted(val apkFile: File) : UpdateDownloadState()
    data class Error(val message: String) : UpdateDownloadState()
}

object AppUpdateManager {
    // اپنی ویب سائٹ کا لائیو URL یہاں لکھیں
    var UPDATE_API_URL = "https://your-website-domain.com/api/update"

    private val _downloadState = MutableStateFlow<UpdateDownloadState>(UpdateDownloadState.Idle)
    val downloadState: StateFlow<UpdateDownloadState> = _downloadState.asStateFlow()

    private val _availableUpdate = MutableStateFlow<UpdateInfo?>(null)
    val availableUpdate: StateFlow<UpdateInfo?> = _availableUpdate.asStateFlow()

    /**
     * ویب سائٹ کی API چیک کرتا ہے کہ نیا ورژن موجود ہے یا نہیں
     */
    suspend fun checkForUpdates(context: Context, customUrl: String? = null): UpdateInfo? = withContext(Dispatchers.IO) {
        val targetUrl = customUrl ?: UPDATE_API_URL
        try {
            val url = URL(targetUrl)
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
            }

            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val jsonString = connection.inputStream.bufferedReader().use { it.readText() }
                val rootJson = JSONObject(jsonString)
                val dataObj = if (rootJson.has("data")) rootJson.getJSONObject("data") else rootJson

                val latestVersionCode = dataObj.optInt("versionCode", 1)
                val currentVersionCode = try {
                    val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        pInfo.longVersionCode.toInt()
                    } else {
                        @Suppress("DEPRECATION")
                        pInfo.versionCode
                    }
                } catch (_: Exception) { 1 }

                if (latestVersionCode > currentVersionCode) {
                    val changelogList = mutableListOf<String>()
                    val changelogArray = dataObj.optJSONArray("changelog")
                    if (changelogArray != null) {
                        for (i in 0 until changelogArray.length()) {
                            changelogList.add(changelogArray.getString(i))
                        }
                    }

                    val info = UpdateInfo(
                        versionName = dataObj.optString("versionName", "1.0.0"),
                        versionCode = latestVersionCode,
                        releaseTitle = dataObj.optString("releaseTitle", "New Update Available"),
                        changelog = changelogList,
                        apkUrl = dataObj.optString("apkUrl", ""),
                        apkSize = dataObj.optString("apkSize", ""),
                        isForceUpdate = dataObj.optBoolean("isForceUpdate", false),
                        minSdk = dataObj.optInt("minSdk", 24)
                    )
                    _availableUpdate.value = info
                    return@withContext info
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        _availableUpdate.value = null
        null
    }

    /**
     * کروم براؤزر کے بغیر ایپ کی انٹرنل کیشے میں APK ڈاؤن لوڈ کرتا ہے
     */
    suspend fun startInAppDownload(context: Context, updateInfo: UpdateInfo) = withContext(Dispatchers.IO) {
        val downloadUrl = updateInfo.apkUrl
        if (downloadUrl.isBlank()) {
            _downloadState.value = UpdateDownloadState.Error("APK URL is invalid.")
            return@withContext
        }

        try {
            _downloadState.value = UpdateDownloadState.Downloading(0, 0, 0)
            val url = URL(downloadUrl)
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000
                readTimeout = 30000
                instanceFollowRedirects = true
            }

            val totalBytes = connection.contentLength.toLong()
            val updatesDir = File(context.cacheDir, "app_updates").apply { mkdirs() }
            val targetApk = File(updatesDir, "LerzaPlayer_v${updateInfo.versionName}.apk")
            if (targetApk.exists()) targetApk.delete()

            connection.inputStream.use { input ->
                FileOutputStream(targetApk).use { output ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    var totalRead = 0L

                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        totalRead += bytesRead
                        val progress = if (totalBytes > 0) ((totalRead * 100) / totalBytes).toInt() else -1
                        _downloadState.value = UpdateDownloadState.Downloading(progress, totalRead, totalBytes)
                    }
                }
            }

            _downloadState.value = UpdateDownloadState.DownloadCompleted(targetApk)
        } catch (e: Exception) {
            e.printStackTrace()
            _downloadState.value = UpdateDownloadState.Error("Download failed: ${e.localizedMessage ?: "Network error"}")
        }
    }

    /**
     * FileProvider کے ذریعے اینڈرائیڈ پیکج انسٹالر کھول کر ان-ایپ انسٹال کرتا ہے
     */
    fun installDownloadedApk(activity: Activity, apkFile: File) {
        if (!apkFile.exists()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!activity.packageManager.canRequestPackageInstalls()) {
                val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                    data = Uri.parse("package:${activity.packageName}")
                }
                activity.startActivity(intent)
                return
            }
        }

        val authority = "${activity.packageName}.fileprovider"
        val apkUri = FileProvider.getUriForFile(activity, authority, apkFile)

        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        activity.startActivity(installIntent)
    }

    fun dismissUpdate() {
        _availableUpdate.value = null
        _downloadState.value = UpdateDownloadState.Idle
    }
}
