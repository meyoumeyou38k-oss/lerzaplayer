# Lerza Player Pro - GitHub Setup & Image Assets Guide

## 1. Logos and Icons Paths
In your GitHub repository, place your image assets inside the `public/` directory:

- `public/logo-transparent.png` -> Transparent Brand Logo (Used in Website Navbar, Phone animation, Footer)
- `public/app-icon.png` -> App Launcher Icon with dark background (Used as fallback and preview)
- `public/favicon.ico` -> Browser tab icon (Shown in Google and browser tabs)

## 2. APK Release File Path
- File Name on GitHub: `LerzaPlayer_v1.0.0.apk`
- Download URL: `/download/LerzaPlayer_v1.0.0.apk`
- Version Name: `1.0.0`
- Version Code: `1`

## 3. In-App Updates Endpoint
Your Android app will query:
```kotlin
AppUpdateManager.UPDATE_API_URL = "https://your-website-domain.com/api/update"
```
Or directly fetch `/update.json`.
