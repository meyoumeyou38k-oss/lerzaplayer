import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.resolve(__dirname, 'public')));

let currentRelease = {
  versionName: "1.0.0",
  versionCode: 1,
  minVersionCode: 1,
  releaseTitle: "Lerza Player Pro 1.0.0 (Official Release)",
  releaseDate: "2026-09-28",
  apkUrl: "/download/LerzaPlayer_v1.0.0.apk",
  apkFileName: "LerzaPlayer_v1.0.0.apk",
  apkSize: "19.8 MB",
  md5Checksum: "e7b39a48f219582d00192a831efcb802",
  isForceUpdate: false,
  minSdk: 24,
  targetSdk: 34,
  changelog: [
    "⚡ Seamless In-App APK Download & Direct Installation (No browser redirect)",
    "🎵 10-Band Precision Equalizer with Lark Jazz & 300% Volume Boost curves",
    "🎤 AI-Powered Synced Karaoke Lyrics with English, Urdu & Hindi translation",
    "🛡️ Private AES-256 Media Vault with Hardware Keystore protection",
    "🎬 Picture-in-Picture (PiP) Floating Video Player with 10s Double-Tap gestures",
    "🌙 Refined Paper-Glass aesthetic with Pure White & AMOLED dark themes"
  ]
};

// CORS
app.use((_req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

app.get('/api/update', (_req, res) => {
  res.json({
    status: 'success',
    data: currentRelease,
    serverTime: new Date().toISOString()
  });
});

app.get('/update.json', (_req, res) => {
  res.json(currentRelease);
});

app.post('/api/update', (req, res) => {
  const updated = req.body;
  if (!updated.versionName || !updated.versionCode) {
    return res.status(400).json({ status: 'error', message: 'Missing fields' });
  }
  currentRelease = { ...currentRelease, ...updated };
  res.json({ status: 'success', data: currentRelease });
});

// Direct clean APK download routes
const serveApk = (_req: express.Request, res: express.Response) => {
  const filename = `LerzaPlayer_v${currentRelease.versionName}.apk`;
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  const dummyApk = Buffer.from(
    'PK\x03\x04\x14\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00AndroidManifest.xml' +
    'LerzaPlayerPro_InApp_OTA_Package_Payload_Test_V_' + currentRelease.versionName +
    'PK\x01\x02\x14\x00\x14\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00AndroidManifest.xml' +
    'PK\x05\x06\x00\x00\x00\x00\x01\x00\x01\x00>\x00\x00\x00b\x00\x00\x00\x00\x00'
  );
  res.send(dummyApk);
};

app.get('/download/:apkName', serveApk);
app.get('/api/download/sample-apk', serveApk);

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }
  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();